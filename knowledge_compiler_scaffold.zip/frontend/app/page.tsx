"use client";

import { useState } from "react";

const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8000";

export default function HomePage() {
  const [title, setTitle] = useState("");
  const [rawText, setRawText] = useState("");
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit() {
    setLoading(true);
    setResult(null);
    try {
      const res = await fetch(`${API_BASE}/v1/documents`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, raw_text: rawText }),
      });
      setResult(await res.json());
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen p-8">
      <div className="mx-auto max-w-4xl space-y-6">
        <header>
          <h1 className="text-3xl font-semibold">Knowledge Compiler</h1>
          <p className="mt-2 text-sm text-gray-600">
            Paste text, compile patterns, and inspect a structured knowledge graph.
          </p>
        </header>

        <section className="rounded-2xl bg-white p-6 shadow-sm border">
          <div className="space-y-4">
            <input
              className="w-full rounded-xl border p-3"
              placeholder="Title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
            <textarea
              className="min-h-56 w-full rounded-xl border p-3"
              placeholder="Paste text here..."
              value={rawText}
              onChange={(e) => setRawText(e.target.value)}
            />
            <button
              onClick={handleSubmit}
              disabled={loading}
              className="rounded-xl bg-black px-4 py-2 text-white disabled:opacity-50"
            >
              {loading ? "Compiling..." : "Compile"}
            </button>
          </div>
        </section>

        {result && (
          <section className="rounded-2xl bg-white p-6 shadow-sm border">
            <h2 className="mb-3 text-lg font-medium">API Result</h2>
            <pre className="overflow-auto rounded-xl bg-zinc-950 p-4 text-sm text-zinc-100">
              {JSON.stringify(result, null, 2)}
            </pre>
          </section>
        )}
      </div>
    </main>
  );
}
