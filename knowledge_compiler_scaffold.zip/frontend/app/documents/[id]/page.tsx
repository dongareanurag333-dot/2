"use client";

import { useEffect, useState } from "react";

const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8000";

export default function DocumentPage({ params }: { params: { id: string } }) {
  const [doc, setDoc] = useState<any>(null);
  const [graph, setGraph] = useState<any>(null);
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState<any>(null);

  useEffect(() => {
    async function load() {
      const d = await fetch(`${API_BASE}/v1/documents/${params.id}`).then((r) => r.json());
      const g = await fetch(`${API_BASE}/v1/graph/${params.id}`).then((r) => r.json());
      setDoc(d);
      setGraph(g);
    }
    load();
  }, [params.id]);

  async function ask() {
    const res = await fetch(`${API_BASE}/v1/query`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ document_id: params.id, question }),
    });
    setAnswer(await res.json());
  }

  return (
    <main className="min-h-screen p-8">
      <div className="mx-auto max-w-5xl space-y-6">
        <header>
          <h1 className="text-3xl font-semibold">{doc?.title || "Document"}</h1>
          <p className="mt-1 text-sm text-gray-600">Status: {doc?.status || "loading"}</p>
        </header>

        <section className="rounded-2xl bg-white p-6 shadow-sm border">
          <h2 className="mb-3 text-lg font-medium">Ask the compiled knowledge</h2>
          <div className="flex gap-2">
            <input
              className="flex-1 rounded-xl border p-3"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="Ask a question about this document"
            />
            <button className="rounded-xl bg-black px-4 py-2 text-white" onClick={ask}>
              Ask
            </button>
          </div>
          {answer && (
            <pre className="mt-4 overflow-auto rounded-xl bg-zinc-950 p-4 text-sm text-zinc-100">
              {JSON.stringify(answer, null, 2)}
            </pre>
          )}
        </section>

        <section className="rounded-2xl bg-white p-6 shadow-sm border">
          <h2 className="mb-3 text-lg font-medium">Patterns</h2>
          <ul className="space-y-2">
            {graph?.nodes?.map((node: any) => (
              <li key={node.id} className="rounded-xl border p-3">
                <div className="font-medium">{node.label}</div>
                <div className="text-sm text-gray-500">
                  {node.subject} / {node.relation} / {node.object}
                </div>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </main>
  );
}
