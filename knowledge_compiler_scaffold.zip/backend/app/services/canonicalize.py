NORMALIZATION = {
    "increase": "↑",
    "rise": "↑",
    "grow": "↑",
    "decrease": "↓",
    "fall": "↓",
    "drop": "↓",
    "lead": "→",
    "cause": "→"
}

def canonicalize_pattern(pattern: dict) -> dict:
    rel = pattern["relation"]
    for key, value in NORMALIZATION.items():
        if key in rel:
            rel = value
    canonical_text = f"{pattern['subject']} {rel} {pattern['object']}"
    return {**pattern, "relation": rel, "canonical_text": canonical_text}
