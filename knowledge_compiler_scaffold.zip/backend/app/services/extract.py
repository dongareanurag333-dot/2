import spacy

nlp = spacy.load("en_core_web_sm")

def extract_patterns(text: str):
    doc = nlp(text)
    patterns = []

    for sent in doc.sents:
        subj = None
        verb = None
        obj = None

        for token in sent:
            if token.dep_ == "nsubj" and subj is None:
                subj = token.lemma_.lower()
            elif token.dep_ == "ROOT" and verb is None:
                verb = token.lemma_.lower()
            elif token.dep_ in ("dobj", "attr", "pobj") and obj is None:
                obj = token.lemma_.lower()

        if subj and verb and obj:
            patterns.append({
                "subject": subj,
                "relation": verb,
                "object": obj,
                "source_text": sent.text.strip(),
                "confidence": 0.7
            })

    return patterns
