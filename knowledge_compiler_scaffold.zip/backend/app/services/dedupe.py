from sentence_transformers import SentenceTransformer
from sklearn.cluster import DBSCAN

embedder = SentenceTransformer("all-MiniLM-L6-v2")

def dedupe_patterns(patterns: list[dict]) -> list[dict]:
    if not patterns:
        return []

    texts = [p["canonical_text"] for p in patterns]
    embeddings = embedder.encode(texts, normalize_embeddings=True)

    clustering = DBSCAN(eps=0.25, min_samples=1, metric="cosine").fit(embeddings)

    deduped = []
    seen = set()
    for idx, label in enumerate(clustering.labels_):
        if label in seen:
            continue
        seen.add(label)
        deduped.append(patterns[idx])

    return deduped
