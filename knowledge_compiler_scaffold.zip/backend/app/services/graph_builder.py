def build_edges(patterns: list[dict]) -> list[dict]:
    edges = []
    for i in range(len(patterns) - 1):
        edges.append({
            "source_index": i,
            "target_index": i + 1,
            "relation_type": "semantic_next"
        })
    return edges
