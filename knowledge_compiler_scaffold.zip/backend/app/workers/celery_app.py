from celery import Celery
from app.core.config import settings

celery_app = Celery(
    "knowledge_compiler",
    broker=settings.REDIS_URL,
    backend=settings.REDIS_URL,
    include=["app.workers.tasks"],
)
