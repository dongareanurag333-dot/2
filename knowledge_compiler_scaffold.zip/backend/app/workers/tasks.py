import uuid
from app.workers.celery_app import celery_app
from app.db.session import SessionLocal
from app.models.document import Document
from app.models.pattern import Pattern
from app.models.edge import Edge
from app.models.job import Job
from app.services.extract import extract_patterns
from app.services.canonicalize import canonicalize_pattern
from app.services.dedupe import dedupe_patterns
from app.services.graph_builder import build_edges

@celery_app.task
def compile_document(document_id: str, job_id: str):
    db = SessionLocal()
    try:
        job = db.query(Job).filter(Job.id == job_id).first()
        doc = db.query(Document).filter(Document.id == document_id).first()

        if not job or not doc:
            return

        job.status = "running"
        job.progress = "10"
        job.message = "Extracting patterns"
        db.commit()

        raw_patterns = extract_patterns(doc.raw_text)
        canonical = [canonicalize_pattern(p) for p in raw_patterns]
        unique_patterns = dedupe_patterns(canonical)

        job.progress = "60"
        job.message = "Saving patterns"
        db.commit()

        saved_patterns = []
        for p in unique_patterns:
            pattern = Pattern(
                id=str(uuid.uuid4()),
                document_id=document_id,
                canonical_text=p["canonical_text"],
                source_text=p["source_text"],
                subject=p["subject"],
                relation=p["relation"],
                object=p["object"],
                confidence=p["confidence"],
            )
            db.add(pattern)
            saved_patterns.append(pattern)

        db.commit()

        edges = build_edges(unique_patterns)
        for e in edges:
            if len(saved_patterns) < 2:
                break
            edge = Edge(
                id=str(uuid.uuid4()),
                document_id=document_id,
                source_pattern_id=saved_patterns[e["source_index"]].id,
                target_pattern_id=saved_patterns[e["target_index"]].id,
                relation_type=e["relation_type"],
            )
            db.add(edge)

        doc.status = "ready"
        job.status = "done"
        job.progress = "100"
        job.message = "Compilation complete"
        db.commit()

    except Exception as ex:
        if job:
            job.status = "failed"
            job.message = str(ex)
            db.commit()
        raise
    finally:
        db.close()
