from pydantic import BaseModel

class DocumentCreate(BaseModel):
    title: str = "Untitled"
    raw_text: str

class DocumentOut(BaseModel):
    id: str
    title: str
    raw_text: str
    status: str
