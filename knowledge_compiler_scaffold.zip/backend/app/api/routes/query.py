from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.models.pattern import Pattern
from app.schemas.query import QueryRequest

router = APIRouter()

@router.post("/query")
def query_knowledge(payload: QueryRequest, db: Session = Depends(get_db)):
    patterns = db.query(Pattern).filter(Pattern.document_id == payload.document_id).all()
    tokens = [t for t in payload.question.lower().split() if len(t) > 2]

    matched = [
        {
            "id": p.id,
            "canonical_text": p.canonical_text,
            "confidence": p.confidence,
        }
        for p in patterns
        if any(token in p.canonical_text.lower() for token in tokens)
    ]

    return {
        "question": payload.question,
        "results": matched[:10]
    }
