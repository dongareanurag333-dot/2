from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.models.pattern import Pattern
from app.models.edge import Edge

router = APIRouter()

@router.get("/graph/{document_id}")
def get_graph(document_id: str, db: Session = Depends(get_db)):
    patterns = db.query(Pattern).filter(Pattern.document_id == document_id).all()
    edges = db.query(Edge).filter(Edge.document_id == document_id).all()

    return {
        "nodes": [
            {
                "id": p.id,
                "label": p.canonical_text,
                "subject": p.subject,
                "relation": p.relation,
                "object": p.object
            }
            for p in patterns
        ],
        "edges": [
            {
                "id": e.id,
                "source": e.source_pattern_id,
                "target": e.target_pattern_id,
                "type": e.relation_type
            }
            for e in edges
        ]
    }
