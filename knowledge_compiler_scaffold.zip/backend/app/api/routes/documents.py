import uuid
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.document import Document
from app.models.job import Job
from app.workers.tasks import compile_document
from app.schemas.document import DocumentCreate

router = APIRouter()

@router.post("/documents")
def create_document(payload: DocumentCreate, db: Session = Depends(get_db)):
    raw_text = payload.raw_text.strip()
    if not raw_text:
        raise HTTPException(status_code=400, detail="raw_text is required")

    doc_id = str(uuid.uuid4())
    job_id = str(uuid.uuid4())

    doc = Document(id=doc_id, title=payload.title, raw_text=raw_text, status="queued")
    job = Job(id=job_id, document_id=doc_id, status="queued", progress="0", message="Queued for compilation")

    db.add(doc)
    db.add(job)
    db.commit()

    compile_document.delay(doc_id, job_id)

    return {"document_id": doc_id, "job_id": job_id, "status": "queued"}

@router.get("/documents/{document_id}")
def get_document(document_id: str, db: Session = Depends(get_db)):
    doc = db.query(Document).filter(Document.id == document_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")

    return {
        "id": doc.id,
        "title": doc.title,
        "raw_text": doc.raw_text,
        "status": doc.status
    }
