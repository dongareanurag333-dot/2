from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.api.routes.documents import router as documents_router
from app.api.routes.graph import router as graph_router
from app.api.routes.query import router as query_router
from app.api.routes.jobs import router as jobs_router
from app.db.base import Base
from app.db.session import engine
from app.models import document, pattern, edge, job  # noqa: F401

app = FastAPI(title="Knowledge Compiler API", version="1.0.0")

origins = [o.strip() for o in settings.CORS_ORIGINS.split(",") if o.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins or ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(documents_router, prefix="/v1", tags=["documents"])
app.include_router(graph_router, prefix="/v1", tags=["graph"])
app.include_router(query_router, prefix="/v1", tags=["query"])
app.include_router(jobs_router, prefix="/v1", tags=["jobs"])

@app.on_event("startup")
def startup():
    Base.metadata.create_all(bind=engine)

@app.get("/health")
def health():
    return {"status": "ok"}
