import uuid
from sqlalchemy import Column, String, DateTime, func, ForeignKey
from app.db.base import Base

class Job(Base):
    __tablename__ = "jobs"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    document_id = Column(String, ForeignKey("documents.id"), index=True, nullable=False)
    status = Column(String, nullable=False, default="queued")
    progress = Column(String, nullable=False, default="0")
    message = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
