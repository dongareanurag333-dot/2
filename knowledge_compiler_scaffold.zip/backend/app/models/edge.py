import uuid
from sqlalchemy import Column, String, ForeignKey, DateTime, func
from app.db.base import Base

class Edge(Base):
    __tablename__ = "edges"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    document_id = Column(String, ForeignKey("documents.id"), index=True, nullable=False)
    source_pattern_id = Column(String, ForeignKey("patterns.id"), index=True, nullable=False)
    target_pattern_id = Column(String, ForeignKey("patterns.id"), index=True, nullable=False)
    relation_type = Column(String, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
