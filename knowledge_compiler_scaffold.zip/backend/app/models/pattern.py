import uuid
from sqlalchemy import Column, String, Text, Float, ForeignKey, DateTime, func
from app.db.base import Base

class Pattern(Base):
    __tablename__ = "patterns"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    document_id = Column(String, ForeignKey("documents.id"), index=True, nullable=False)
    canonical_text = Column(Text, nullable=False)
    source_text = Column(Text, nullable=False)
    subject = Column(String, index=True)
    relation = Column(String, index=True)
    object = Column(String, index=True)
    confidence = Column(Float, default=0.0)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
